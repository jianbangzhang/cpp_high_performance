#!/bin/bash
# alltests.sh                                            2016-10-27 Agner Fog
# (c) Copyright 2013-2016 by Agner Fog. GNU General Public License www.gnu.org/licenses

# pack all results into zipfile
zip -q allresults.zip results/* results1/* results2/*
