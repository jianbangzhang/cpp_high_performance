# Uninstall MSR driver
rm -f /dev/MSRdrv
rmmod MSRdrv
# modprobe -r MSRdrv
